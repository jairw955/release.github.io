# RKNN3 Download API V2 分发说明

[English](DISTRIBUTION.md)

## 分发边界

RKNN3 Download API V2 是通过公共 C ABI 提供 Catalog 发现和模型资源下载能力的 provider-neutral 原生库。库支持 Lenovo 和 ModelScope provider，provider 配置与应用策略由消费者负责。

唯一受支持的公共 ABI 头文件是 `include/rknn3_model/downloader.h`。分发内容包括目标平台库、该头文件、适用的运行时依赖和随附许可证材料；不包括模型文件或应用业务逻辑。APIV2 原生安装树本身不包含 Catalog helper 可执行程序；rknn3-center 产品包会将 Center 自建的 `model-apiv2-catalog-helper` 作为相邻的独立组件加入，该 helper 不属于 APIV2 公共 ABI。

## Windows x86_64 LLVM-MinGW

Windows x86_64 LLVM-MinGW 安装树包含 `bin/rknn3_download_api_v2.dll`、`bin/libc++.dll`、`bin/libunwind.dll`、`bin/libwinpthread-1.dll`、`include/rknn3_model/downloader.h`，以及 `lib/` 下的导入库。应将四个 DLL 放在同一应用目录，或通过 `PATH` 提供其所在目录。

Windows 库使用 WinHTTP 和 SChannel，不需要 OpenSSL 库、OpenSSL CA bundle 或 OpenSSL 相关环境变量。

## Linux

Linux 安装树包含 `lib/librknn3_download_api_v2.so` 和 `include/rknn3_model/downloader.h`。该库依赖与目标系统匹配的 glibc、C++ 运行时及 OpenSSL 3，包括 `libssl.so.3` 和 `libcrypto.so.3`；本分发不捆绑系统 OpenSSL。

发布前应使用 `file` 和 `readelf` 核验目标架构及动态链接契约，再在与目标兼容的系统上使用 `ldd` 确认所有运行时依赖均解析到预期 ABI。

## 集成与兼容性

消费者只能基于 `include/rknn3_model/downloader.h` 编译，不得依赖 `include/core`、`include/net` 或 `include/provider` 下的内部头文件。公共头文件和运行时库必须来自同一次构建，不得跨构建混用不同平台或工具链的导入库。

模型资源在运行时从消费者提供的配置来源获取。分发包及其日志不得写入分享 URL、提取码、token、Cookie、Authorization 值或 Catalog 私有配置。

## 许可证与再分发

源码根目录的 `LICENSE` 和 `NOTICE` 必须随每份分发内容提供。再分发前必须由产品和法务审核 SDK 条款及所有捆绑的第三方运行库许可证；本文档不宣称已经获得公开分发许可。
