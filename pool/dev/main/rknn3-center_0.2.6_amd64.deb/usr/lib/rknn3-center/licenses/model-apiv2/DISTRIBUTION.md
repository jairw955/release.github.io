# RKNN3 Download API V2 Distribution

[中文](DISTRIBUTION.cn.md)

## Distribution scope

RKNN3 Download API V2 is a provider-neutral native library for catalog discovery and model resource downloads through a public C ABI. The library supports Lenovo and ModelScope providers, while provider configuration and application policy remain the responsibility of the consumer.

The only supported public ABI header is `include/rknn3_model/downloader.h`. A distribution contains the target library, this header, applicable runtime dependencies, and the accompanying license materials; it does not contain model files or application business logic. The APIV2 native install tree itself does not contain the Catalog helper executable; the rknn3-center product package adds the Center-built `model-apiv2-catalog-helper` as a separate adjacent component, and that helper is not part of the APIV2 public ABI.

## Windows x86_64 LLVM-MinGW

The Windows x86_64 LLVM-MinGW install tree contains `bin/rknn3_download_api_v2.dll`, `bin/libc++.dll`, `bin/libunwind.dll`, `bin/libwinpthread-1.dll`, `include/rknn3_model/downloader.h`, and the import library under `lib/`. Place all four DLLs in the same application directory or make their directory available through `PATH`.

The Windows library uses WinHTTP and SChannel. It does not require OpenSSL libraries, an OpenSSL CA bundle, or OpenSSL-related environment variables.

## Linux

The Linux install tree contains `lib/librknn3_download_api_v2.so` and `include/rknn3_model/downloader.h`. The library depends on target-compatible glibc and C++ runtimes plus OpenSSL 3, including `libssl.so.3` and `libcrypto.so.3`; system OpenSSL is not bundled in this distribution.

Before release, use `file` and `readelf` to verify the target architecture and dynamic contract, then use `ldd` on the target-compatible system to confirm that every runtime dependency resolves to the intended ABI.

## Integration and compatibility

Consumers must compile only against `include/rknn3_model/downloader.h` and must not depend on internal headers under `include/core`, `include/net`, or `include/provider`. The public header and runtime library must come from the same build, and platform- or toolchain-specific import libraries must not be mixed across builds.

Model resources are obtained at runtime from consumer-provided configuration. The distribution and its logs must not embed share URLs, extraction codes, tokens, cookies, Authorization values, or private Catalog configuration.

## License and redistribution

The source-root `LICENSE` and `NOTICE` files must accompany every distribution. Redistribution requires product and legal review of the SDK terms and all bundled third-party runtime licenses; this document does not assert that public redistribution permission has been granted.
