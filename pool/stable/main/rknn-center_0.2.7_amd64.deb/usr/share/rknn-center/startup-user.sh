#!/bin/sh
set -eu
action=$1
owned() {
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    case "$(head -n 1 "$1")" in
    '# RKNN Center managed startup' | '# RKNN3 Center managed startup') return 0 ;;
    *) return 1 ;;
    esac
}
if [ "$action" = remove ]; then
    for product in rknn-center rknn3-center; do
        unit="$XDG_CONFIG_HOME/systemd/user/$product-gateway.service"
        link="$XDG_CONFIG_HOME/systemd/user/default.target.wants/$product-gateway.service"
        if owned "$unit"; then
            fragment=$(systemctl --user show "$product-gateway.service" --property=FragmentPath --value 2>/dev/null || true)
            if [ -n "$fragment" ] && [ "$(readlink -f "$fragment")" = "$(readlink -f "$unit")" ]; then
                systemctl --user stop "$product-gateway.service" || true
            fi
            [ "$(readlink "$link" 2>/dev/null)" != "$unit" ] || rm -f "$link"
            rm -f "$unit"
            systemctl --user daemon-reload || true
        fi
    done
    for identifier in com.rockchip.rknn.center com.rockchip.rknn3.center; do
        desktop="$XDG_CONFIG_HOME/autostart/$identifier.desktop"
        if owned "$desktop"; then rm -f "$desktop"; fi
    done
    exit 0
fi
echo "error: only startup removal is supported" >&2
exit 1
