#!/bin/sh
# Package lifecycle helpers; source only, with the invoking account explicit.
rknn_startup_user() {
    startup_user=$1
    shift
    runuser -u "$startup_user" -- env -i PATH=/usr/bin:/bin HOME="$startup_home" \
        XDG_CONFIG_HOME="$startup_home/.config" \
        XDG_RUNTIME_DIR="/run/user/$startup_uid" \
        DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$startup_uid/bus" "$@"
}

rknn_startup_remove() {
    # Cleanup runs as each account, never following user paths as root.
    getent passwd | while IFS=: read -r startup_user _ startup_uid _ _ startup_home _; do
        [ -d "$startup_home" ] || continue
        rknn_startup_user "$startup_user" sh /usr/share/rknn-center/startup-user.sh remove || echo "warning: startup cleanup failed for $startup_user" >&2
    done
    # Linger and persisted preferences may be used by other services/reinstall.
}
